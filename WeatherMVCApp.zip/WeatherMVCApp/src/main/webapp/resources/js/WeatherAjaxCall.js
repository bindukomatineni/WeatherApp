var fetch_weather_info = function(){
	 $("#theJson").html('');
	 $("#weatherDiv").html('');
	 var cityName = document.getElementById("cityName").value;
	 if(cityName===""){
		var errorString = '<p style="color:red;">city name cannot be empty</p>';
		$("#errorDiv").html(errorString);
		return;
	 } else if(cityName!=""){
		 var letters = /^[A-Za-z]+$/;
		 if(!cityName.match(letters))
		 {
		  $("#errorDiv").html('<p style="color:red;">city name should only have alphabets</p>');
		  return;
		 }
	 }
	 $("#errorDiv").html('');
	
	 var url = "/weather/getWeatherJson/"+cityName;
	 $.ajax({
	        type: 'GET',
	        url:  url,
	        async: true,
	        success: function(result) {
	        	if(result){
	        		$("#theJson").append('<tr><th> Name </th> <th> City </th> <th> State </th> <th> Country </th> <th> Country_iso3166 </th> <th> Country Name </th> <th> ZMW </th><th> location </th>');
	        		$.map(result, function (val , i) {
		        		var htm = '<tr class="rows"><td>' + val.name + '</td><td>' + val.city + '</td><td>' + val.state + '</td><td>' + val.country + '</td><td>' + val.country_iso3166 + '</td><td>'+  val.country_name + '</td><td>'+  val.zmw + '</td><td>' + '<a href= javascript:void(0)>' + val.l+ '</a>'  + '</td></tr>';
		        		$("#theJson").append(htm);
		        	})
	        	} else {
	        		$("#theJson").append("No results found");
	        	}
	        	
	        },
	        error: function(jqXHR, textStatus, errorThrown) {
	            alert("Issue fetching the JSON: "
	                + textStatus + " "
	                + errorThrown + " !");
	        }

	    });
	 $(document).on("click","tr.rows td", function(e){
		 $("#weatherDiv").html('');
		    var url = "http://api.wunderground.com/api/0febb2c6dfdd1e46/conditions/q/"+e.target.innerHTML+'.json';
		    $.ajax({
		        type: 'GET',
		        url:  url,
		        async: true,
		        success: function(result) {
		        	if(result.current_observation){
		        		
		        		$("#weatherDiv").append('<tr><th> Temperature </th> <th> Feels Like </th> <th> Weather condition </th> <th> Wind Direction</th> <th> Wind Speed </th> <th> Elevation </th> <th> Station Id </th>');
		        		$.map(result.current_observation, function (val , i) {
		        			
		        				var htm = '<tr><td>' + temperature_string + '</td><td>' + feelslike_string + '</td><td>' + weather + '</td><td>' + wind_dir + '</td><td>' + wind_mph + '</td><td>'+  elevation + '</td><td>'+  station_id + '</td></tr>';
				        		$("#weatherDiv").append(htm);
		        			
			        		
			        	})
		        	} else {
		        		$("#errorDiv").append("No results found");
		        	}
		        	
		        },
		        error: function(jqXHR, textStatus, errorThrown) {
		            alert("Issue fetching the Weather : "
		                + textStatus + " "
		                + errorThrown + " !");
		        }

		    });
		});
}