package com.example.weather.service;

import java.util.List;

import com.example.weather.model.Weather;

public interface WeatherService {
	
	public List<Weather> getWeather(String city);

}
