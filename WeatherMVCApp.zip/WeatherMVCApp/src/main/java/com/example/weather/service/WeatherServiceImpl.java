package com.example.weather.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.ws.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestOperations;

import com.example.weather.model.Weather;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;


@Component("weatherClient")
public class WeatherServiceImpl implements WeatherService{
	private static final Logger logger = LoggerFactory.getLogger(WeatherServiceImpl.class);
	private static final String WEATHER_URL = "http://api.wunderground.com/api/0febb2c6dfdd1e46/conditions/q/";
	
	@Autowired
    private RestOperations restTemplate;


	@SuppressWarnings("unchecked")
	@Override
	public List<Weather> getWeather(String city) {
		List<Weather> weatherList = new ArrayList<Weather>();
		List<MediaType> mediaTypes = new ArrayList<MediaType>();
        mediaTypes.add(MediaType.APPLICATION_JSON);
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(mediaTypes);
        try {
        	logger.info("Calling weather api for : " + city);
        	String url = WEATHER_URL+city+".json";
            ResponseEntity<String> jsonStringResponse = restTemplate.exchange(url, HttpMethod.GET, null,
                    String.class);
            logger.info("Response String : " + jsonStringResponse.getBody());
            if(jsonStringResponse.getStatusCode() == HttpStatus.OK) {
            	logger.info("Calling weather api for : " + city);
            	ObjectMapper mapper = new ObjectMapper();
            	try {
					Map<String,Object> map = mapper.readValue(jsonStringResponse.getBody(), Map.class);
					Map<String,Object> resultMap = (Map<String, Object>) map.get("response");
					weatherList = (List<Weather>) resultMap.get("results");
				} catch (JsonParseException e) {
					e.printStackTrace();
					throw new RuntimeException(e);
				} catch (JsonMappingException e) {
					e.printStackTrace();
					throw new RuntimeException(e);
				} catch (IOException e) {
					e.printStackTrace();
					throw new RuntimeException(e);
				}
            }
        } catch (RuntimeException e) {
            e.printStackTrace();
            logger.error("Exception whie calling weather api for : " + city + " as : "+ e.getMessage());
            throw e;
        }
		return weatherList;
	}

}
